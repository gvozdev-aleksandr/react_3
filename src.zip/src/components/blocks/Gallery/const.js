export const GALLERY_ITEM = {
    width: '280px',
    widthLarge: '580px',
    height: '250px',
};
