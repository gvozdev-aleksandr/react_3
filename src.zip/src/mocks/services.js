export const Services = [
    {
        id: 1,
        text: 'Прогулки в горы летом',
        isNew: false
    },
    {
        id: 2,
        text: 'Зимние походы в горы',
        isNew: false
    },
    {
        id: 3,
        text: 'Посещение храмов в горах',
        isNew: false
    },
    {
        id: 4,
        text: 'Экстремальные виды туризма',
        isNew: false
    },
    {
        id: 5,
        text: 'Походы в джунглях Амазонии',
        isNew: true
    },
    {
        id: 6,
        text: 'Поездка в Африку',
        isNew: false
    }
];
